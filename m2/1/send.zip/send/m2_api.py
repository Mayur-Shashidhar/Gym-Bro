"""
M2 - Public API
==============
The only file other modules (M1, M3, M4, M5, M6) need to import from.

Quick-start
-----------
from m2_api import SkeletonTracker, SkeletonFrame, stream_webcam, stream_video

# One-shot frame (e.g. inside M5's Streamlit loop):
tracker = SkeletonTracker()
frame   = tracker.process_frame(bgr_frame)
# frame.landmarks_norm  → dict[joint_name → {x, y, z}]
# frame.visible         → dict[joint_name → bool]
# frame.feature_vector  → list[float], length = 39 (13 joints × 3)
# frame.annotated_frame → BGR ndarray with skeleton drawn on

# Streaming webcam (M5 main loop):
for frame in stream_webcam(show_preview=False):
    if frame.pose_detected:
        ...

# Video file (M6 dataset prep):
for frame in stream_video("squat.mp4"):
    ...

tracker.release()
"""

# Re-export everything downstream modules need
from skeleton_tracker import SkeletonTracker, SkeletonFrame       # noqa: F401
from stream            import stream_webcam, stream_video         # noqa: F401
from landmark_utils    import (                                    # noqa: F401
    LANDMARK_NAMES,
    LANDMARK_INDEX,
    EXERCISE_JOINTS,
    POSE_CONNECTIONS,
    VISIBILITY_THRESHOLD,
    to_feature_vector,
    normalize_landmarks,
    build_visibility_mask,
)
