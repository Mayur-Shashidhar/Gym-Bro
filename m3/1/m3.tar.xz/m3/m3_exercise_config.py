"""
M3 - Exercise configuration
Add/modify exercises here without changing rep-detection logic.
"""

from dataclasses import dataclass
from typing import Dict, Optional, Tuple


@dataclass(frozen=True)
class ExerciseProfile:
    name: str
    aliases: Tuple[str, ...]
    signal_left_angle: str
    signal_right_angle: str
    signal_aggregate: str  # min | mean | max | left | right
    visibility_joints: Tuple[str, ...]
    side_gap_left_angle: Optional[str]
    side_gap_right_angle: Optional[str]
    down_threshold: float
    up_threshold: float
    smooth_window: int
    min_frames_between_reps: int
    dynamic_calibration: bool
    calibration_frames: int
    max_side_gap_deg: float
    phase_timeout_frames: int


EXERCISE_PROFILES: Dict[str, ExerciseProfile] = {
    "squat": ExerciseProfile(
        name="squat",
        aliases=("squat", "air_squat", "bodyweight_squat"),
        signal_left_angle="left_knee",
        signal_right_angle="right_knee",
        signal_aggregate="min",
        visibility_joints=(
            "LEFT_HIP", "LEFT_KNEE", "LEFT_ANKLE",
            "RIGHT_HIP", "RIGHT_KNEE", "RIGHT_ANKLE",
        ),
        side_gap_left_angle="left_knee",
        side_gap_right_angle="right_knee",
        down_threshold=95.0,
        up_threshold=155.0,
        smooth_window=5,
        min_frames_between_reps=8,
        dynamic_calibration=True,
        calibration_frames=75,
        max_side_gap_deg=20.0,
        phase_timeout_frames=45,
    ),
    "pushup": ExerciseProfile(
        name="pushup",
        aliases=("pushup", "push_up", "push-up"),
        signal_left_angle="left_elbow",
        signal_right_angle="right_elbow",
        signal_aggregate="mean",
        visibility_joints=(
            "LEFT_SHOULDER", "LEFT_ELBOW", "LEFT_WRIST",
            "RIGHT_SHOULDER", "RIGHT_ELBOW", "RIGHT_WRIST",
        ),
        side_gap_left_angle="left_elbow",
        side_gap_right_angle="right_elbow",
        down_threshold=85.0,
        up_threshold=150.0,
        smooth_window=5,
        min_frames_between_reps=6,
        dynamic_calibration=True,
        calibration_frames=75,
        max_side_gap_deg=22.0,
        phase_timeout_frames=40,
    ),
    "bicep_curl": ExerciseProfile(
        name="bicep_curl",
        aliases=("bicep_curl", "curl", "dumbbell_curl"),
        signal_left_angle="left_elbow",
        signal_right_angle="right_elbow",
        signal_aggregate="mean",
        visibility_joints=(
            "LEFT_SHOULDER", "LEFT_ELBOW", "LEFT_WRIST",
            "RIGHT_SHOULDER", "RIGHT_ELBOW", "RIGHT_WRIST",
        ),
        side_gap_left_angle="left_elbow",
        side_gap_right_angle="right_elbow",
        down_threshold=60.0,
        up_threshold=135.0,
        smooth_window=4,
        min_frames_between_reps=6,
        dynamic_calibration=True,
        calibration_frames=75,
        max_side_gap_deg=24.0,
        phase_timeout_frames=40,
    ),
    "lunge": ExerciseProfile(
        name="lunge",
        aliases=("lunge", "lunges"),
        signal_left_angle="left_knee",
        signal_right_angle="right_knee",
        signal_aggregate="mean",
        visibility_joints=(
            "LEFT_HIP", "LEFT_KNEE", "LEFT_ANKLE",
            "RIGHT_HIP", "RIGHT_KNEE", "RIGHT_ANKLE",
        ),
        side_gap_left_angle="left_knee",
        side_gap_right_angle="right_knee",
        down_threshold=100.0,
        up_threshold=160.0,
        smooth_window=5,
        min_frames_between_reps=8,
        dynamic_calibration=True,
        calibration_frames=75,
        max_side_gap_deg=30.0,
        phase_timeout_frames=45,
    ),
}


def normalize_exercise_name(exercise_name: str) -> str:
    return exercise_name.strip().lower().replace(" ", "_")


def get_exercise_profile(exercise_name: str) -> Optional[ExerciseProfile]:
    normalized = normalize_exercise_name(exercise_name)
    for profile in EXERCISE_PROFILES.values():
        if normalized in profile.aliases:
            return profile
    return None


def list_supported_exercises() -> Tuple[str, ...]:
    return tuple(EXERCISE_PROFILES.keys())
