"""
M3 - Rep detection
Tracks movement patterns from angle signals using a lightweight state machine.
"""

from dataclasses import dataclass, field
from typing import Deque, Dict, List, Optional
from collections import deque

import numpy as np

from m3_angles import compute_named_angles, exercise_signal_angle
from m3_exercise_config import ExerciseProfile, get_exercise_profile


@dataclass
class RepState:
    rep_count: int = 0
    phase: str = "start"  # start -> down -> up
    last_signal: Optional[float] = None
    smoothed_signal: Optional[float] = None
    last_rep_frame: int = -10**9
    valid_signal_frames: int = 0
    last_rep_confidence: float = 0.0
    rep_confidences: List[float] = field(default_factory=list)
    rejected_reps: int = 0
    calibration_complete: bool = False
    calibration_frames_seen: int = 0
    active_down_threshold: Optional[float] = None
    active_up_threshold: Optional[float] = None


@dataclass
class RepCounter:
    exercise_name: str
    down_threshold: float
    up_threshold: float
    smooth_window: int = 5
    min_frames_between_reps: int = 8
    dynamic_calibration: bool = True
    calibration_frames: int = 75
    calibration_low_percentile: float = 20.0
    calibration_high_percentile: float = 85.0
    calibration_threshold_margin: float = 5.0
    min_threshold_gap: float = 20.0
    max_side_gap_deg: float = 22.0
    phase_timeout_frames: int = 45
    _buffer: Deque[float] = field(default_factory=lambda: deque(maxlen=5))
    _calibration_values: List[float] = field(default_factory=list)
    _phase_start_frame: int = -1
    _cycle_max_side_gap: float = 0.0
    _cycle_signal_min: Optional[float] = None
    _cycle_signal_max: Optional[float] = None
    _cycle_visibility_sum: float = 0.0
    _cycle_visibility_count: int = 0
    _cycle_roughness_sum: float = 0.0
    _cycle_last_smooth: Optional[float] = None
    _profile: Optional[ExerciseProfile] = None
    state: RepState = field(default_factory=RepState)

    def __post_init__(self):
        self._profile = get_exercise_profile(self.exercise_name)
        self._buffer = deque(maxlen=max(1, int(self.smooth_window)))
        self.state.active_down_threshold = float(self.down_threshold)
        self.state.active_up_threshold = float(self.up_threshold)
        self.state.calibration_complete = not self.dynamic_calibration
        self.state.phase = "calibrating" if self.dynamic_calibration else "start"

    def reset(self) -> None:
        self._buffer.clear()
        self.state = RepState()
        self._calibration_values.clear()
        self._phase_start_frame = -1
        self._reset_cycle_metrics()
        self.state.active_down_threshold = float(self.down_threshold)
        self.state.active_up_threshold = float(self.up_threshold)
        self.state.calibration_complete = not self.dynamic_calibration
        self.state.phase = "calibrating" if self.dynamic_calibration else "start"

    def _reset_cycle_metrics(self) -> None:
        self._cycle_max_side_gap = 0.0
        self._cycle_signal_min = None
        self._cycle_signal_max = None
        self._cycle_visibility_sum = 0.0
        self._cycle_visibility_count = 0
        self._cycle_roughness_sum = 0.0
        self._cycle_last_smooth = None

    def _set_phase(self, phase: str, frame_id: int) -> None:
        self.state.phase = phase
        self._phase_start_frame = frame_id
        if phase == "down":
            self._reset_cycle_metrics()

    def _exercise_side_gap(self, angles: Dict[str, Optional[float]]) -> Optional[float]:
        if self._profile is None:
            return None

        left_name = self._profile.side_gap_left_angle
        right_name = self._profile.side_gap_right_angle
        if left_name is None or right_name is None:
            return None

        left = angles.get(left_name)
        right = angles.get(right_name)

        if left is None or right is None:
            return None

        return abs(float(left) - float(right))

    def _relevant_visibility_ratio(self, visible: Dict[str, bool]) -> float:
        if self._profile is None:
            joints = list(visible.keys())
        else:
            joints = self._profile.visibility_joints

        if not joints:
            return 0.0
        seen = sum(1 for joint in joints if visible.get(joint, False))
        return float(seen / len(joints))

    def _update_cycle_metrics(
        self,
        smooth_signal: float,
        visibility_ratio: float,
        side_gap: Optional[float],
    ) -> None:
        if self._cycle_signal_min is None:
            self._cycle_signal_min = smooth_signal
            self._cycle_signal_max = smooth_signal
        else:
            self._cycle_signal_min = min(self._cycle_signal_min, smooth_signal)
            self._cycle_signal_max = max(self._cycle_signal_max, smooth_signal)

        if self._cycle_last_smooth is not None:
            self._cycle_roughness_sum += abs(smooth_signal - self._cycle_last_smooth)
        self._cycle_last_smooth = smooth_signal

        self._cycle_visibility_sum += visibility_ratio
        self._cycle_visibility_count += 1

        if side_gap is not None:
            self._cycle_max_side_gap = max(self._cycle_max_side_gap, side_gap)

    def _compute_rep_confidence(self) -> float:
        if self._cycle_signal_min is None or self._cycle_signal_max is None:
            return 0.0

        amplitude = self._cycle_signal_max - self._cycle_signal_min
        threshold_gap = max(1e-6, float(self.up_threshold - self.down_threshold))
        amplitude_score = float(np.clip(amplitude / threshold_gap, 0.0, 1.0))

        steps = max(1, self._cycle_visibility_count - 1)
        smooth_den = max(1e-6, amplitude * steps)
        smoothness = float(np.clip(1.0 - (self._cycle_roughness_sum / smooth_den), 0.0, 1.0))

        visibility_score = 0.0
        if self._cycle_visibility_count > 0:
            visibility_score = float(np.clip(
                self._cycle_visibility_sum / self._cycle_visibility_count,
                0.0,
                1.0,
            ))

        confidence = (0.45 * amplitude_score) + (0.30 * smoothness) + (0.25 * visibility_score)
        return float(np.clip(confidence, 0.0, 1.0))

    def _finalize_calibration_if_ready(self) -> None:
        if not self.dynamic_calibration or self.state.calibration_complete:
            return

        if self.state.calibration_frames_seen < self.calibration_frames:
            return

        values = np.array(self._calibration_values, dtype=np.float32)
        if values.size == 0:
            return

        low = float(np.percentile(values, self.calibration_low_percentile))
        high = float(np.percentile(values, self.calibration_high_percentile))
        if high < low:
            low, high = high, low

        down = low + self.calibration_threshold_margin
        up = high - self.calibration_threshold_margin

        if (up - down) < self.min_threshold_gap:
            center = 0.5 * (high + low)
            half_gap = 0.5 * self.min_threshold_gap
            down = center - half_gap
            up = center + half_gap

        self.down_threshold = float(down)
        self.up_threshold = float(up)
        self.state.active_down_threshold = self.down_threshold
        self.state.active_up_threshold = self.up_threshold
        self.state.calibration_complete = True
        self.state.phase = "start"
        self._phase_start_frame = -1

    def update_from_landmarks(
        self,
        landmarks_norm: Dict[str, Dict],
        visible: Dict[str, bool],
        frame_id: int,
    ) -> RepState:
        """Update rep count using normalized landmarks for one frame."""
        angles = compute_named_angles(landmarks_norm, visible)
        signal = exercise_signal_angle(self.exercise_name, angles)
        side_gap = self._exercise_side_gap(angles)

        self.state.last_signal = signal
        if signal is None:
            return self.state

        signal_value = float(signal)
        self._buffer.append(signal_value)
        smooth_signal = float(np.mean(self._buffer))
        self.state.smoothed_signal = smooth_signal
        self.state.valid_signal_frames += 1

        if self.dynamic_calibration and not self.state.calibration_complete:
            self._calibration_values.append(smooth_signal)
            self.state.calibration_frames_seen += 1
            self._finalize_calibration_if_ready()
            return self.state

        if self.state.phase == "down" and self._phase_start_frame >= 0:
            if (frame_id - self._phase_start_frame) > self.phase_timeout_frames:
                self._set_phase("start", frame_id)
                self._reset_cycle_metrics()
                return self.state

        visibility_ratio = self._relevant_visibility_ratio(visible)

        if self.state.phase in {"start", "up"}:
            crossed_down = (smooth_signal <= self.down_threshold) or (signal_value <= self.down_threshold)
            if crossed_down:
                self._set_phase("down", frame_id)
                self._update_cycle_metrics(smooth_signal, visibility_ratio, side_gap)

        elif self.state.phase == "down":
            self._update_cycle_metrics(smooth_signal, visibility_ratio, side_gap)

            crossed_up = (smooth_signal >= self.up_threshold) or (signal_value >= self.up_threshold)
            side_ok = (side_gap is None) or (self._cycle_max_side_gap <= self.max_side_gap_deg)
            if (
                crossed_up
                and side_ok
                and (frame_id - self.state.last_rep_frame) >= self.min_frames_between_reps
            ):
                self.state.rep_count += 1
                self.state.last_rep_frame = frame_id
                self.state.last_rep_confidence = self._compute_rep_confidence()
                self.state.rep_confidences.append(self.state.last_rep_confidence)
                self._set_phase("up", frame_id)
                self._reset_cycle_metrics()
            elif crossed_up and not side_ok:
                self.state.rejected_reps += 1
                self._set_phase("up", frame_id)
                self._reset_cycle_metrics()

        return self.state

    def update_from_skeleton(self, skeleton) -> RepState:
        """
        Convenience adapter for M2 SkeletonFrame-like objects.
        Requires: .landmarks_norm, .visible, .frame_id, .pose_detected
        """
        if not getattr(skeleton, "pose_detected", False):
            return self.state

        return self.update_from_landmarks(
            landmarks_norm=skeleton.landmarks_norm,
            visible=skeleton.visible,
            frame_id=skeleton.frame_id,
        )


def default_rep_counter(exercise_name: str) -> RepCounter:
    """Factory with practical defaults per exercise."""
    profile = get_exercise_profile(exercise_name)
    if profile is None:
        return RepCounter(
            exercise_name=exercise_name,
            down_threshold=90.0,
            up_threshold=150.0,
            smooth_window=5,
            min_frames_between_reps=8,
            dynamic_calibration=True,
            calibration_frames=75,
            max_side_gap_deg=22.0,
            phase_timeout_frames=45,
        )

    return RepCounter(
        exercise_name=exercise_name,
        down_threshold=profile.down_threshold,
        up_threshold=profile.up_threshold,
        smooth_window=profile.smooth_window,
        min_frames_between_reps=profile.min_frames_between_reps,
        dynamic_calibration=profile.dynamic_calibration,
        calibration_frames=profile.calibration_frames,
        max_side_gap_deg=profile.max_side_gap_deg,
        phase_timeout_frames=profile.phase_timeout_frames,
    )
